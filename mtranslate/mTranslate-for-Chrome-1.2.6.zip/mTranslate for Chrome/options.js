// Settings page (right-click the toolbar icon → Options, or ⚙︎ Settings in the popup).

const select = document.getElementById("myLanguage");
const saved = document.getElementById("saved");
let savedTimer = null;

function save(values) {
  chrome.storage.sync.set(values, () => {
    saved.textContent = "Saved";
    clearTimeout(savedTimer);
    savedTimer = setTimeout(() => { saved.textContent = ""; }, 1500);
  });
}

(async () => {
  for (const code of MT.LANGUAGES) select.add(new Option(MT.languageName(code), code));
  const s = await MT.getSettings();
  select.value = s.myLanguage;
  document.querySelector(`input[name=selectMode][value=${s.selectMode}]`).checked = true;
  document.querySelector(`input[name=chineseVoice][value=${s.chineseVoice}]`).checked = true;
  const size = document.querySelector(`input[name=textSize][value="${s.textSize}"]`);
  if (size) size.checked = true;
  document.getElementById("sentence").checked = s.sentence;

  select.addEventListener("change", () => save({ myLanguage: select.value }));
  for (const radio of document.querySelectorAll("input[type=radio]")) {
    radio.addEventListener("change", () => save({ [radio.name]: radio.name === "textSize" ? Number(radio.value) : radio.value }));
  }
  document.getElementById("sentence").addEventListener("change", (e) => save({ sentence: e.target.checked }));
})();

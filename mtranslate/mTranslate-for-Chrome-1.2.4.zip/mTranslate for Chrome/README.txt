mTranslate for Chrome
=====================

Select text on a web page to see its translation and hear it.
Translation and voices run on your computer. Your text isn't sent anywhere.

How to install
1. Keep this folder somewhere it will stay, for example in Documents. Chrome uses it from here.
2. In Chrome, open chrome://extensions
3. Turn on "Developer mode" (top right).
4. Press "Load unpacked" and choose this folder.
5. Press the puzzle icon in Chrome's toolbar and pin mTranslate.

How to use
- Select text or double-click a word. A yellow bubble shows the translation. Press the speaker to hear it.
- Or select text, right-click, and choose mTranslate.
- "Settings" in the bubble opens the settings page.
- Press the mTranslate icon in the toolbar to type or paste text.

Settings
Right-click the mTranslate icon → Options (or ⚙︎ Settings in the toolbar window):
my language, what happens when you select text, Cantonese or Mandarin voice,
and whether single words also show the sentence they're in.

mStudio Solutions · https://mstudio-solutions.github.io/mtranslate/

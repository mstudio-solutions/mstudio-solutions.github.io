// Right-click menu.

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "mtranslate",
    title: "mTranslate “%s”",
    contexts: ["selection"]
  });
});

// Right-click → mTranslate: show the bubble on the page.
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "mtranslate" || !info.selectionText) return;
  const frameId = info.frameId ?? 0;
  const message = { type: "show", text: info.selectionText };
  try {
    await chrome.tabs.sendMessage(tab.id, message, { frameId });
    return;
  } catch {
    // Tabs opened before the extension was installed or reloaded don't have the bubble yet.
  }
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [frameId] }, files: ["shared.js", "content.js"] });
    await chrome.tabs.sendMessage(tab.id, message, { frameId });
  } catch {
    // The extension can't run on this page (chrome:// pages, the PDF viewer): use the full page instead.
    openPage(info.selectionText, tab);
  }
});

function openPage(text, tab) {
  chrome.tabs.create({
    url: "translate.html?full=1&text=" + encodeURIComponent(text.slice(0, 5000)),
    index: tab ? tab.index + 1 : undefined
  });
}

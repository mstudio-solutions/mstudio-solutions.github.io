// The toolbar popup, and the full page that "More »" and "Open in a tab" open.

// The colour speaker emoji: a little friendlier than a flat icon.
const SPEAKER = '<span class="emoji" aria-hidden="true">🔊</span>';
const params = new URLSearchParams(location.search);
const full = params.has("full");
document.body.classList.add(full ? "full" : "popup");

const $ = (id) => document.getElementById(id);
const input = $("input"), output = $("output"), from = $("from"), to = $("to"), note = $("note");
$("sayIn").innerHTML = SPEAKER;
$("sayOut").innerHTML = SPEAKER;

let lastSource = "en";
let lastTarget = "zh-Hant";
let timer = null;
let run = 0;

function fillSelect(select, withDetect) {
  select.innerHTML = "";
  if (withDetect) select.add(new Option("Detect language", "auto"));
  for (const code of MT.LANGUAGES) select.add(new Option(MT.languageName(code), code));
}

async function translateNow() {
  const text = input.value.trim();
  const id = ++run;
  note.textContent = "";
  if (!text) { output.textContent = ""; return; }
  output.textContent = "…";
  const source = from.value === "auto" ? await MT.detect(text) : from.value;
  let target = to.value;
  // "Detect" and the text is already in the target language: go the other way.
  if (from.value === "auto" && MT.base(source) === MT.base(target)) {
    const { myLanguage } = await MT.getSettings();
    target = MT.targetFor(source, myLanguage);
  }
  try {
    const result = await MT.translate(text, source, target, (status) => { if (id === run) output.textContent = status; });
    if (id !== run) return;
    output.textContent = result;
    lastSource = source;
    lastTarget = target;
    if (from.value === "auto") note.textContent = MT.languageName(source) + " → " + MT.languageName(target);
  } catch (err) {
    if (id !== run) return;
    output.textContent = err.message;
    if (err.needsClick) {
      const button = document.createElement("button");
      button.textContent = "Download and translate";
      button.style.marginTop = "10px";
      button.addEventListener("click", translateNow);
      output.append(document.createElement("br"), button);
    }
  }
}

function later() {
  clearTimeout(timer);
  timer = setTimeout(translateNow, 400);
}

input.addEventListener("input", later);
from.addEventListener("change", translateNow);
to.addEventListener("change", translateNow);

$("swap").addEventListener("click", () => {
  const newFrom = to.value;
  to.value = from.value === "auto" ? lastSource : from.value;
  from.value = newFrom;
  if (output.textContent && output.textContent !== "…") input.value = output.textContent;
  translateNow();
});
$("clear").addEventListener("click", () => { input.value = ""; output.textContent = ""; note.textContent = ""; input.focus(); });
$("sayIn").addEventListener("click", async () => {
  const text = input.value.trim();
  if (text) MT.speak(text, from.value === "auto" ? await MT.detect(text) : from.value, $("sayIn"));
});
$("sayOut").addEventListener("click", () => { if (output.textContent) MT.speak(output.textContent, lastTarget, $("sayOut")); });
$("copy").addEventListener("click", async () => {
  if (!output.textContent) return;
  await navigator.clipboard.writeText(output.textContent);
  note.textContent = "Copied";
});
$("openFull").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "translate.html?full=1&text=" + encodeURIComponent(input.value) });
  window.close();
});
$("openSettings").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

(async () => {
  fillSelect(from, true);
  fillSelect(to, false);
  const { myLanguage } = await MT.getSettings();
  to.value = myLanguage;
  input.value = params.get("text") || "";
  input.focus();
  if (input.value) translateNow();
})();

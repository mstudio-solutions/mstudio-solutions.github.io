// Shared by the page bubble (content script), the toolbar popup, the full page and the settings page.
// Translation uses Chrome's built-in Translator: on this computer, free, nothing sent anywhere.

// `var` + check, because background.js may inject this file again into a page that has it.
var MT = globalThis.MT || (() => {
  const DEFAULTS = {
    myLanguage: "zh-Hant",
    selectMode: "popup", // "popup" | "icon" | "off"
    chineseVoice: "yue", // "yue" (Cantonese) | "zh" (Mandarin)
    sentence: true // single word: also translate the sentence around it
  };

  // Chrome doesn't list its translator languages, so these are the common ones it supports.
  const LANGUAGES = ["zh-Hant", "zh", "en", "ja", "ko", "fr", "de", "es", "it", "pt", "nl", "sv", "da", "fi", "no",
    "pl", "cs", "ru", "uk", "tr", "ar", "he", "hi", "bn", "th", "vi", "id", "ms"];

  // The bubble's own words, in the reader's language (My language). Others fall back to English.
  const LABELS = {
    en: { sentence: "The whole sentence", settings: "Settings", speak: "Read aloud", close: "Close" },
    "zh-Hant": { sentence: "全句翻譯", settings: "設定", speak: "讀出", close: "關閉" },
    zh: { sentence: "全句翻译", settings: "设置", speak: "朗读", close: "关闭" },
    ja: { sentence: "文全体の翻訳", settings: "設定", speak: "読み上げ", close: "閉じる" },
    ko: { sentence: "전체 문장 번역", settings: "설정", speak: "읽어 주기", close: "닫기" },
    fr: { sentence: "La phrase entière", settings: "Réglages", speak: "Lire à voix haute", close: "Fermer" },
    de: { sentence: "Der ganze Satz", settings: "Einstellungen", speak: "Vorlesen", close: "Schließen" },
    es: { sentence: "La frase completa", settings: "Ajustes", speak: "Leer en voz alta", close: "Cerrar" },
    it: { sentence: "La frase intera", settings: "Impostazioni", speak: "Leggi ad alta voce", close: "Chiudi" },
    pt: { sentence: "A frase completa", settings: "Definições", speak: "Ler em voz alta", close: "Fechar" },
    vi: { sentence: "Cả câu", settings: "Cài đặt", speak: "Đọc to", close: "Đóng" },
    th: { sentence: "ทั้งประโยค", settings: "การตั้งค่า", speak: "อ่านออกเสียง", close: "ปิด" },
    id: { sentence: "Seluruh kalimat", settings: "Pengaturan", speak: "Bacakan", close: "Tutup" }
  };

  function label(key, myLanguage) {
    const set = LABELS[myLanguage] || LABELS[myLanguage.split("-")[0]] || LABELS.en;
    return set[key];
  }

  function getSettings() {
    return new Promise((resolve) => chrome.storage.sync.get(DEFAULTS, resolve));
  }

  /** Each language in its own words: 中文（繁體）, English, 日本語 … */
  function languageName(code) {
    if (code === "zh-Hant") return "中文（繁體）";
    if (code === "zh") return "中文（简体）";
    try {
      const name = new Intl.DisplayNames([code], { type: "language" }).of(code);
      return name.charAt(0).toLocaleUpperCase(code) + name.slice(1);
    } catch {
      return code;
    }
  }

  const base = (code) => code.split("-")[0];

  function looksChinese(text) {
    const han = (text.match(/[㐀-鿿]/g) || []).length;
    return han > 0 && han >= text.replace(/\s/g, "").length / 3;
  }

  let detector = null;
  async function detect(text) {
    if (looksChinese(text)) return "zh-Hant";
    if ("LanguageDetector" in self) {
      try {
        detector = detector || (await LanguageDetector.create());
        const [top] = await detector.detect(text);
        if (top && top.confidence > 0.5 && top.detectedLanguage !== "und") {
          return base(top.detectedLanguage) === "zh" ? "zh-Hant" : top.detectedLanguage;
        }
      } catch {
        // fall through to the simple guess
      }
    }
    return "en";
  }

  /** Text already in my language goes into English (or into Chinese if my language is English). */
  function targetFor(source, myLanguage) {
    if (base(source) !== base(myLanguage)) return myLanguage;
    return base(myLanguage) === "en" ? "zh-Hant" : "en";
  }

  const translators = new Map();

  function withTimeout(promise, ms, message) {
    return Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms))]);
  }

  /**
   * onStatus(text) shows progress, for example while Chrome downloads a language the first time.
   * A download needs a click or key press; without one the error has needsClick = true.
   */
  async function translate(text, source, target, onStatus = () => {}) {
    if (base(source) === base(target) && source !== "zh" && target !== "zh") return text;
    if (!("Translator" in self)) throw new Error("This Chrome has no built-in translation. Update Chrome to use mTranslate.");
    const key = source + ">" + target;
    if (!translators.has(key)) {
      const ask = (from) => withTimeout(Translator.availability({ sourceLanguage: from, targetLanguage: target }), 8000,
        "Chrome's translator didn't answer. Try again.");
      let from = source;
      let availability = await ask(from);
      if (availability === "unavailable" && from === "zh-Hant") {
        // Some Chrome versions only accept plain "zh" as a source.
        from = "zh";
        availability = await ask(from);
      }
      if (availability === "unavailable") throw new Error("Chrome can't translate between these two languages yet.");
      if (availability !== "available") onStatus("Downloading the language. This happens only once…");
      translators.set(key, Translator.create({ sourceLanguage: from, targetLanguage: target }));
    }
    let translator;
    try {
      translator = await translators.get(key);
    } catch (err) {
      translators.delete(key);
      const e = new Error(err && err.name === "NotAllowedError"
        ? "Chrome needs a click to download this language (first time only)."
        : "Couldn't get the translator ready. Try again.");
      e.needsClick = err && err.name === "NotAllowedError";
      throw e;
    }
    try {
      return await translator.translate(text);
    } catch {
      throw new Error("Couldn't translate. Try again in a moment.");
    }
  }

  // ---- voice ----

  let voices = [];
  const loadVoices = () => { voices = speechSynthesis.getVoices().filter((v) => v.localService); };
  loadVoices();
  speechSynthesis.addEventListener("voiceschanged", loadVoices);

  // macOS also lists novelty voices (Albert, Bells, …); the usual ones come first.
  const PREFERRED = ["Sinji", "Meijia", "Tingting", "Samantha", "Daniel", "Karen", "Moira", "Kyoko", "Yuna", "Thomas", "Anna", "Mónica", "Alice"];

  function voiceFor(lang, chineseVoice) {
    let wants;
    if (base(lang) === "zh") wants = chineseVoice === "zh" ? ["zh-TW", "zh-CN"] : ["yue-HK", "zh-HK", "zh-TW"];
    else if (base(lang) === "en") wants = ["en-US", "en-GB", "en-AU", "en"];
    else wants = [lang];
    for (const want of wants) {
      const matching = voices.filter((v) => v.lang.replace("_", "-").startsWith(want));
      const voice = matching.find((v) => PREFERRED.some((p) => v.name.startsWith(p))) || matching.find((v) => v.default) || matching[0];
      if (voice) return voice;
    }
    return null;
  }

  /** Press once to hear it, press again to stop. Only the Mac's own voices: Google's online voices would send the text to Google. */
  // button (optional) pulses while it reads.
  let speakingButton = null;
  async function speak(text, lang, button) {
    if (speechSynthesis.speaking) {
      speechSynthesis.cancel();
      if (speakingButton) speakingButton.classList.remove("speaking");
      return;
    }
    const { chineseVoice } = await getSettings();
    if (!voices.length) loadVoices();
    const u = new SpeechSynthesisUtterance(text);
    const voice = voiceFor(lang, chineseVoice);
    u.voice = voice;
    u.lang = voice ? voice.lang : lang;
    if (button) {
      speakingButton = button;
      button.classList.add("speaking");
      u.onend = u.onerror = () => button.classList.remove("speaking");
    }
    speechSynthesis.speak(u);
  }

  return { DEFAULTS, LANGUAGES, label, getSettings, languageName, detect, targetFor, translate, speak, base };
})();

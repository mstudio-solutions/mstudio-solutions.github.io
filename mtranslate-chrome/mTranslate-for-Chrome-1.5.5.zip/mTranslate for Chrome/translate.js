// The toolbar popup, and the full page that "More »" and "Open in a tab" open.

// The colour speaker emoji: a little friendlier than a flat icon.
const SPEAKER = '<span class="emoji" aria-hidden="true">🔊</span>';
const params = new URLSearchParams(location.search);
const full = params.has("full");
document.body.classList.add(full ? "full" : "popup");

const $ = (id) => document.getElementById(id);
const input = $("input"), output = $("output"), from = $("from"), to = $("to"), note = $("note");
$("sayIn").innerHTML = SPEAKER;
$("sayOut").innerHTML = SPEAKER;

let lastSource = "en";
let myLang = "en"; // the language of this window's own words
let lastTarget = "zh-Hant";
let timer = null;
let run = 0;

function fillSelect(select, withDetect) {
  select.innerHTML = "";
  if (withDetect) select.add(new Option(MT.t("detect_language"), "auto"));
  for (const code of MT.LANGUAGES) select.add(new Option(MT.languageName(code), code));
}

async function translateNow() {
  const text = input.value.trim();
  const id = ++run;
  note.textContent = "";
  if (!text) { output.textContent = ""; return; }
  output.textContent = "…";
  const source = from.value === "auto" ? await MT.detect(text) : from.value;
  let target = to.value;
  // "Detect" and the text is already in the target language: go the other way.
  if (from.value === "auto" && MT.base(source) === MT.base(target)) {
    const { myLanguage } = await MT.getSettings();
    target = MT.targetFor(source, myLanguage);
  }
  try {
    const result = await MT.translate(text, source, target, (status) => { if (id === run) output.textContent = status; });
    if (id !== run) return;
    output.textContent = result;
    lastSource = source;
    lastTarget = target;
    if (from.value === "auto") note.textContent = MT.languageName(source) + " → " + MT.languageName(target);
  } catch (err) {
    if (id !== run) return;
    output.textContent = err.message;
    if (err.needsClick) {
      const button = document.createElement("button");
      button.textContent = MT.label("download", myLang);
      button.style.marginTop = "10px";
      button.addEventListener("click", translateNow);
      output.append(document.createElement("br"), button);
    }
  }
}

function later() {
  clearTimeout(timer);
  timer = setTimeout(translateNow, 400);
}

input.addEventListener("input", later);
from.addEventListener("change", translateNow);
to.addEventListener("change", translateNow);

$("swap").addEventListener("click", () => {
  const newFrom = to.value;
  to.value = from.value === "auto" ? lastSource : from.value;
  from.value = newFrom;
  if (output.textContent && output.textContent !== "…") input.value = output.textContent;
  translateNow();
});
$("clear").addEventListener("click", () => { input.value = ""; output.textContent = ""; note.textContent = ""; input.focus(); });
$("sayIn").addEventListener("click", async () => {
  const text = input.value.trim();
  if (text) MT.speak(text, from.value === "auto" ? await MT.detect(text) : from.value, $("sayIn"));
});
$("sayOut").addEventListener("click", () => { if (output.textContent) MT.speak(output.textContent, lastTarget, $("sayOut")); });
$("copy").addEventListener("click", async () => {
  if (!output.textContent) return;
  await navigator.clipboard.writeText(output.textContent);
  note.textContent = MT.t("copied");
});
$("openFull").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "translate.html?full=1&text=" + encodeURIComponent(input.value) });
  window.close();
});
// Translate (or turn back) the page in the tab behind this window.
// Talks to the page directly; opening this window lets the extension use the current tab.
$("translatePage").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  await getPairReady(tab);
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "page" });
  } catch {
    // The tab was open before the extension was installed or updated: add our scripts first.
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["i18n.js", "shared.js", "content.js", "page.js"], injectImmediately: true });
      await chrome.tabs.sendMessage(tab.id, { type: "page" });
    } catch {
      note.textContent = MT.t("cant_translate_page");
      return;
    }
  }
  window.close();
});

/**
 * Chrome lets mTranslate translate a language pair without a click only after mTranslate itself has
 * used it once. This button press counts as that click, so get the page's pair ready here first;
 * then the page is translated at once, and other websites with the same language too.
 */
async function getPairReady(tab) {
  if (!("Translator" in self)) return;
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  try {
    const answer = await Promise.race([chrome.tabs.sendMessage(tab.id, { type: "pageLanguage?" }), wait(1500)]);
    const source = answer && answer.lang;
    const { myLanguage } = await MT.getSettings();
    if (!source || MT.base(source) === MT.base(myLanguage)) return;
    const status = await MT.availability(source, myLanguage);
    if (status === "available" || status === "unavailable") return;
    await Promise.race([Translator.create({ sourceLanguage: source, targetLanguage: myLanguage }), wait(4000)]);
  } catch {
    // no answer from the page, or Chrome said no: the page asks for the click itself as before
  }
}

$("openSettings").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

(async () => {
  const settings = await MT.getSettings();
  const { myLanguage, textSize } = settings;
  myLang = MT.uiOf(settings); // this window's own words follow the Interface language
  MT.translateScreen(document, myLang);
  fillSelect(from, true);
  fillSelect(to, false);
  to.value = myLanguage;
  $("translatePage").textContent = "🌐 " + MT.label("translatePage", myLang);
  // If the page behind is already translated, the button turns it back.
  if (!full) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const state = tab && (await chrome.tabs.sendMessage(tab.id, { type: "pageState?" }));
      if (state && (state.active || state.stale)) $("translatePage").textContent = "🌐 " + MT.label("showOriginal", myLang);
    } catch {
      // no mTranslate on that page yet, so it isn't translated
    }
  }
  document.body.style.zoom = textSize || 1; // Settings → Text size
  input.value = params.get("text") || "";
  input.focus();
  if (input.value) translateNow();
})();

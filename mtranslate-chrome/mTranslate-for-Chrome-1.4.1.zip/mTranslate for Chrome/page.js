// Translate the page, like Chrome's own "Translate to …", but on this computer:
// each piece of text is replaced with its translation, and a yellow bar at the top
// shows the progress and a "Show original" button. Started from the right-click menu
// or the toolbar window; asking again turns the page back.
// Only what's on screen (and a little below) is translated; the rest follows as it
// scrolls into view or appears (for example the next question in a quiz), so long
// pages start fast.

(() => {
  if (window.__mTranslatePageLoaded) return;
  window.__mTranslatePageLoaded = true;

  const SKIP = "script, style, noscript, textarea, input, select, code, pre, kbd, samp, svg, math, iframe, [contenteditable=''], [contenteditable='true'], [translate='no'], .notranslate";
  const AT_ONCE = 6; // pieces translated at the same time

  const originals = new Map(); // text node → its original text
  let active = false;
  let bar = null;
  let run = 0;
  let ui = "en"; // language of the bar's own words (Interface language)

  // While a page is translated:
  let job = null; // { me, source, target }
  let waiting = new Map(); // element not yet on screen → its text nodes
  let queue = []; // text nodes on screen, waiting for their turn
  let queued = new WeakSet();
  let working = 0;
  let done = 0;
  let onScreen = null; // IntersectionObserver
  let changes = null; // MutationObserver

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    // The toolbar window asks, so its button can say "Show original".
    if (message.type === "pageState?") {
      sendResponse({ active });
      return;
    }
    if (message.type !== "page") return;
    sendResponse({ ok: true }); // answer at once, otherwise Chrome treats the message as failed
    if (active) restore();
    else translatePage();
  });

  /** Lets the right-click menu say "Show original" on this tab. */
  function report() {
    try {
      chrome.runtime.sendMessage({ type: "pageState", active }).catch(() => {});
    } catch {
      // the extension was reloaded; this old copy can't talk to it any more
    }
  }

  /** Once the page is done, the bar goes away so it doesn't cover the page. */
  let hideTimer = null;
  function hideBarSoon() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(removeBar, 1500);
  }

  // ---- pieces of text ----

  function wanted(node) {
    const text = node.nodeValue;
    if (!text || !/\p{L}/u.test(text)) return false; // only spaces, numbers or symbols
    if (looksLikeName(text.trim())) return false;
    const parent = node.parentElement;
    if (!parent || parent.closest(SKIP)) return false;
    if (parent.closest("[data-mtranslate]")) return false; // our own bar and bubble
    return true;
  }

  /**
   * A single word written like a name stays as it is: a capital inside the word (mCurrency, iOS,
   * macOS, YouTube) or all capitals (FAQ, USB). Translators turn these into odd words.
   */
  function looksLikeName(text) {
    if (/\s/.test(text)) return false;
    const word = text.replace(/[^\p{L}\p{N}]/gu, "");
    if (word.length < 2) return false;
    return /\p{Ll}\p{Lu}/u.test(word) || (/^\p{Lu}+$/u.test(word) && word.length <= 6);
  }

  function collect(root) {
    const nodes = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (wanted(n) && !originals.has(n) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT)
    });
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
  }

  /** Page language: the page says it, or guess from a sample of its text. */
  async function pageLanguage() {
    const sample = (document.body.innerText || "").slice(0, 1500);
    const guessed = await MT.detect(sample);
    const said = (document.documentElement.lang || "").trim();
    if (said && MT.base(said) !== "zh") return MT.base(guessed) === MT.base(said) ? guessed : said;
    return guessed;
  }

  // ---- translate and restore ----

  async function translatePage() {
    const me = ++run;
    active = true;
    const settings = await MT.getSettings();
    const target = settings.myLanguage;
    ui = MT.uiOf(settings);
    const source = await pageLanguage();
    if (run !== me) return;

    showBar(settings, source, target);
    if (MT.base(source) === MT.base(target)) {
      setStatus(MT.label("alreadyIn", ui) + " " + MT.languageName(target));
      active = false;
      hideBarSoon();
      return;
    }

    job = { me, source, target };
    done = 0;
    report();
    setStatus(MT.label("translating", ui));
    // A piece is translated once its element comes near the screen.
    onScreen = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        onScreen.unobserve(entry.target);
        for (const node of waiting.get(entry.target) || []) enqueue(node);
        waiting.delete(entry.target);
      }
      pump();
    }, { rootMargin: "600px 0px" });
    track(collect(document.body));

    // Text the page adds later (more results, "Load more", the next question).
    changes = new MutationObserver((mutations) => {
      const nodes = [];
      for (const m of mutations) {
        for (const added of m.addedNodes) {
          if (added.nodeType === Node.TEXT_NODE) {
            if (wanted(added) && !originals.has(added)) nodes.push(added);
          } else if (added.nodeType === Node.ELEMENT_NODE && !added.closest("[data-mtranslate]")) {
            nodes.push(...collect(added));
          }
        }
      }
      track(nodes);
    });
    changes.observe(document.body, { childList: true, subtree: true });
  }

  /** Waits for each piece's element to come near the screen. */
  function track(nodes) {
    for (const node of nodes) {
      const el = node.parentElement;
      if (!el || queued.has(node)) continue;
      if (!waiting.has(el)) {
        waiting.set(el, []);
        onScreen.observe(el);
      }
      waiting.get(el).push(node);
    }
  }

  function enqueue(node) {
    if (queued.has(node)) return;
    queued.add(node);
    queue.push(node);
  }

  /** Keeps up to AT_ONCE pieces translating. */
  function pump() {
    if (!job) return;
    const { me, source, target } = job;
    while (working < AT_ONCE && queue.length) {
      const node = queue.shift();
      working++;
      translateNode(node, source, target, (status) => setStatus(status))
        .catch((err) => {
          if (err.needsClick && run === me) stop(err, target);
        })
        .finally(() => {
          working--;
          if (run !== me) return;
          done++;
          if (queue.length || working) {
            clearTimeout(hideTimer);
            setStatus(MT.label("translating", ui) + " " + done);
          } else {
            setStatus(MT.label("translatedTo", ui) + " " + MT.languageName(target));
            hideBarSoon();
          }
          pump();
        });
    }
  }

  /** Chrome needs a click to download the language: stop and offer it. */
  function stop(err, target) {
    disconnect();
    active = false;
    report();
    setStatus(err.message);
    offerDownload(target);
  }

  function disconnect() {
    if (onScreen) onScreen.disconnect();
    if (changes) changes.disconnect();
    onScreen = changes = job = null;
    waiting = new Map();
    queue = [];
    queued = new WeakSet();
  }

  async function translateNode(node, source, target, onStatus) {
    const text = node.nodeValue;
    const lead = text.match(/^\s*/)[0];
    const trail = text.match(/\s*$/)[0];
    const core = text.trim();
    if (!core || !node.isConnected) return;
    const result = await MT.translate(core, source, target, onStatus);
    if (!active || !node.isConnected) return;
    originals.set(node, text);
    node.nodeValue = lead + result + trail;
  }

  function restore() {
    run++;
    active = false;
    report();
    disconnect();
    for (const [node, text] of originals) {
      if (node.isConnected) node.nodeValue = text;
    }
    originals.clear();
    removeBar();
  }

  // ---- the yellow bar ----

  function showBar(settings, source, target) {
    removeBar();
    bar = document.createElement("div");
    bar.setAttribute("data-mtranslate", "bar");
    bar.style.cssText = "all:initial;position:fixed;top:10px;right:10px;z-index:2147483647;";
    const root = bar.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        .bar { display: flex; align-items: center; gap: 10px; background: #ffffdd; color: #222; border: 1px solid #bbb;
          border-radius: 6px; padding: 8px 10px 8px 12px; box-shadow: 0 3px 10px rgba(0,0,0,.2);
          font: 13px/1.4 -apple-system, BlinkMacSystemFont, "PingFang HK", "Segoe UI", sans-serif; }
        img { width: 18px; height: 18px; }
        .status { color: #444; }
        a { color: #1a0dab; cursor: pointer; text-decoration: none; white-space: nowrap; }
        a:hover { text-decoration: underline; }
        button { all: unset; cursor: pointer; color: #777; padding: 0 2px; font-size: 14px; }
        button:hover { color: #333; }
      </style>
      <div class="bar" role="status">
        <img alt="">
        <span class="status"></span>
        <a class="original"></a>
        <button class="x" title="">✕</button>
      </div>`;
    root.querySelector("img").src = chrome.runtime.getURL("icons/icon-32.png");
    root.querySelector(".original").textContent = MT.label("showOriginal", ui);
    root.querySelector(".original").onclick = () => restore();
    root.querySelector(".x").title = MT.label("close", ui);
    // Closing the bar keeps the translation; the right-click menu turns the page back.
    root.querySelector(".x").onclick = removeBar;
    bar.style.zoom = settings.textSize || 1;
    document.documentElement.appendChild(bar);
  }

  /** The first time, Chrome only downloads a language after a click on the page itself. */
  function offerDownload(target) {
    const link = bar && bar.shadowRoot.querySelector(".original");
    if (!link) return;
    link.textContent = MT.label("download", ui);
    link.onclick = () => translatePage();
  }

  function setStatus(text) {
    const status = bar && bar.shadowRoot.querySelector(".status");
    if (status) status.textContent = text;
  }

  function removeBar() {
    if (bar) bar.remove();
    bar = null;
  }
})();

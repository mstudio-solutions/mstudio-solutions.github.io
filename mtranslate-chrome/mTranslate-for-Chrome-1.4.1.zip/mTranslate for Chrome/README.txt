mTranslate for Chrome
=====================

Select text on a web page to see its translation and hear it, or translate the whole page.
Translation and voices run on your computer. Your text isn't sent anywhere.

How to install
1. Keep this folder somewhere it will stay, for example in Documents. Chrome uses it from here.
2. In Chrome, open chrome://extensions
3. Turn on "Developer mode" (top right).
4. Press "Load unpacked" and choose this folder.
5. Press the puzzle icon in Chrome's toolbar and pin mTranslate.

How to use
- Select text or double-click a word. A yellow bubble shows the translation. Press the speaker to hear it.
- Or select text, right-click, and choose mTranslate.
- "Settings" in the bubble opens the settings page.
- Press the mTranslate icon in the toolbar to type or paste text.
- Translate the whole page: right-click an empty spot on the page and choose
  "mTranslate: Translate this page", or press the mTranslate icon and then
  "Translate this page". The icon gets a green frame while the page is translated.
  Do the same again ("Show original") to turn it back.
- After installing or updating, reload pages that were already open.

Settings
Right-click the mTranslate icon → Options (or ⚙︎ Settings in the toolbar window):
my language (at first, Chrome's language), text size, what happens when you
select text, Cantonese or Mandarin voice, whether single words also show the
sentence they're in, and languages for use without internet.

mStudio Solutions · https://mstudio-solutions.github.io/mtranslate-chrome/

// A hidden mTranslate page that translates for web pages (opened by background.js).
// Chrome asks for a click on every new website before it translates there, to protect privacy.
// Here the translating always happens in the same place, mTranslate itself, so once a language
// pair has been used by mTranslate, every website can be translated without that extra click.

const translators = new Map(); // "en>zh-Hant" → Promise<Translator>
const notHere = new Set(); // pairs this page can't do without a click; the web page does them itself

async function translatorFor(source, target) {
  const key = source + ">" + target;
  if (notHere.has(key)) return null;
  if (!translators.has(key)) {
    let status;
    try {
      status = await Translator.availability({ sourceLanguage: source, targetLanguage: target });
    } catch {
      status = "unavailable";
    }
    // Anything but "available" would need a click or a download: leave that to the web page.
    if (status !== "available") {
      notHere.add(key);
      return null;
    }
    translators.set(key, Translator.create({ sourceLanguage: source, targetLanguage: target }));
  }
  try {
    return await translators.get(key);
  } catch {
    translators.delete(key);
    return null;
  }
}

async function translate({ text, source, target }) {
  const key = source + ">" + target;
  let translator = await translatorFor(source, target);
  if (!translator) return { ok: false };
  try {
    return { ok: true, result: await translator.translate(text) };
  } catch {
    // Chrome can close a translator after a while: make a fresh one and try once more.
    translators.delete(key);
    translator = await translatorFor(source, target);
    if (!translator) return { ok: false };
    try {
      return { ok: true, result: await translator.translate(text) };
    } catch {
      translators.delete(key);
      return { ok: false };
    }
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  // Simplified ⇄ Traditional with the whole word list (chinese.js).
  if (message.type === "mt-offscreen-convert") {
    try {
      sendResponse({ ok: true, result: MTChinese.convert(message.text, message.target) });
    } catch {
      sendResponse({ ok: false });
    }
    return;
  }
  if (message.type !== "mt-offscreen-translate") return;
  translate(message).then(sendResponse, () => sendResponse({ ok: false }));
  return true; // the answer comes later
});

// A language pair that became available later (downloaded in Settings or the toolbar window).
setInterval(() => notHere.clear(), 60 * 1000);

// Simplified ⇄ Traditional Chinese.
// Chrome's translator treats this as a translation and rewrites the meaning (首页 became 斬首),
// so mTranslate swaps the characters itself, with OpenCC's lists (chinese-chars.js, and
// chinese-phrases.js where it's loaded: the hidden page and the toolbar window).
// Words come first, so 头发 → 頭髮 but 发现 → 發現; the rest goes character by character.

var MTChinese = (() => {
  const tables = {};

  function table(direction, withPhrases) {
    const key = direction + (withPhrases ? "+" : "");
    if (tables[key]) return tables[key];
    const map = new Map();
    let longest = 1;
    const add = (list) => {
      for (const entry of list.split("|")) {
        const [from, to] = entry.split(" ");
        map.set(from, to);
        longest = Math.max(longest, [...from].length);
      }
    };
    add(MT_ZH_CHARS[direction]);
    if (withPhrases) add(MT_ZH_PHRASES[direction]);
    return (tables[key] = { map, longest });
  }

  const hasPhrases = () => typeof MT_ZH_PHRASES !== "undefined";

  // OpenCC's Traditional uses some older forms (爲, 喫, 羣, 峯, 麪, 臺). These are the ones people in
  // Hong Kong and Taiwan write today (from OpenCC's TW and HK variant lists).
  const MODERN = new Map(Object.entries({
    "僞": "偽", "啓": "啟", "喫": "吃", "峯": "峰", "爲": "為", "牀": "床", "羣": "群", "衆": "眾", "祕": "秘",
    "纔": "才", "脣": "唇", "癡": "痴", "竈": "灶", "糉": "粽", "麪": "麵", "着": "著", "臺": "台", "嫺": "嫻", "鉢": "缽"
  }));
  const modern = (text) => { let out = ""; for (const c of text) out += MODERN.get(c) || c; return out; };

  /** "Hant" (Traditional) or "Hans" (Simplified) for a language code like zh, zh-Hant, zh-TW, zh-CN. */
  function script(code) {
    return /^zh-(hant|tw|hk|mo)\b/i.test(code || "") ? "Hant" : "Hans";
  }

  /** Text in Traditional or Simplified, into the script of `target` (a language code). */
  function convert(text, target) {
    const direction = script(target) === "Hant" ? "s2t" : "t2s";
    const { map, longest } = table(direction, hasPhrases());
    const chars = [...text];
    let out = "";
    for (let i = 0; i < chars.length;) {
      let done = false;
      for (let n = Math.min(longest, chars.length - i); n >= 1; n--) {
        const piece = n === 1 ? chars[i] : chars.slice(i, i + n).join("");
        const to = map.get(piece);
        if (to !== undefined) {
          out += to;
          i += n;
          done = true;
          break;
        }
      }
      if (!done) out += chars[i++];
    }
    return direction === "s2t" ? modern(out) : out;
  }

  /**
   * Is this Chinese text Simplified ("zh") or Traditional ("zh-Hant")? Counts the characters that
   * only exist in one of them. null when it can't tell (only characters both use, like 中文).
   */
  function kind(text) {
    const s2t = table("s2t", false).map;
    const t2s = table("t2s", false).map;
    let simplified = 0;
    let traditional = 0;
    for (const c of text) {
      const toT = s2t.get(c);
      const toS = t2s.get(c);
      if (toT !== undefined && toT !== c) simplified++;
      if (toS !== undefined && toS !== c) traditional++;
    }
    if (simplified === traditional) return null;
    return simplified > traditional ? "zh" : "zh-Hant";
  }

  return { convert, kind, script, hasPhrases };
})();

// Settings page (right-click the toolbar icon → Options, or ⚙︎ Settings in the popup).

const select = document.getElementById("myLanguage");
const saved = document.getElementById("saved");
let savedTimer = null;

function save(values) {
  chrome.storage.sync.set(values, () => {
    saved.textContent = "Saved";
    clearTimeout(savedTimer);
    savedTimer = setTimeout(() => { saved.textContent = ""; }, 1500);
  });
}

(async () => {
  for (const code of MT.LANGUAGES) select.add(new Option(MT.languageName(code), code));
  const s = await MT.getSettings();
  select.value = s.myLanguage;
  document.querySelector(`input[name=selectMode][value=${s.selectMode}]`).checked = true;
  document.querySelector(`input[name=chineseVoice][value=${s.chineseVoice}]`).checked = true;
  const size = document.querySelector(`input[name=textSize][value="${s.textSize}"]`);
  if (size) size.checked = true;
  document.getElementById("sentence").checked = s.sentence;

  select.addEventListener("change", () => save({ myLanguage: select.value }));
  for (const radio of document.querySelectorAll("input[type=radio]")) {
    radio.addEventListener("change", () => save({ [radio.name]: radio.name === "textSize" ? Number(radio.value) : radio.value }));
  }
  document.getElementById("sentence").addEventListener("change", (e) => save({ sentence: e.target.checked }));
  select.addEventListener("change", () => { checkOffline(); listLanguages(); });
  checkOffline();
  listLanguages();
})();

// ---- Use without internet ----

const offlineStatus = document.getElementById("offlineStatus");
const offlineButton = document.getElementById("offlineButton");

/** My language and the one it's translated into (English, or Chinese if my language is English). */
function offlinePair() {
  const mine = select.value;
  return [mine, MT.targetFor(mine, mine)];
}

async function checkOffline() {
  const [a, b] = offlinePair();
  document.getElementById("offlinePair").textContent = MT.languageName(a) + " ⇄ " + MT.languageName(b);
  if (!("Translator" in self)) {
    offlineStatus.textContent = "This Chrome has no built-in translation";
    offlineButton.hidden = true;
    return;
  }
  const [there, back] = await Promise.all([
    Translator.availability({ sourceLanguage: a, targetLanguage: b }),
    Translator.availability({ sourceLanguage: b, targetLanguage: a })
  ]);
  if (there === "unavailable" || back === "unavailable") {
    offlineStatus.textContent = "Not available";
    offlineButton.hidden = true;
  } else if (there === "available" && back === "available") {
    offlineStatus.textContent = "✅ Ready";
    offlineButton.hidden = true;
  } else {
    offlineStatus.textContent = "Not downloaded yet";
    offlineButton.hidden = false;
  }
}

// The button press lets Chrome download the languages (it needs a click).
offlineButton.addEventListener("click", async () => {
  const [a, b] = offlinePair();
  offlineButton.disabled = true;
  const progress = (m) => m.addEventListener("downloadprogress", (e) => {
    offlineStatus.textContent = "Downloading… " + Math.round(e.loaded * 100) + "%";
  });
  try {
    offlineStatus.textContent = "Downloading…";
    await Translator.create({ sourceLanguage: a, targetLanguage: b, monitor: progress });
    await Translator.create({ sourceLanguage: b, targetLanguage: a, monitor: progress });
    if ("LanguageDetector" in self) await LanguageDetector.create({ monitor: progress });
  } catch {
    offlineStatus.textContent = "Couldn't download. Check the internet and try again.";
    offlineButton.disabled = false;
    return;
  }
  offlineButton.disabled = false;
  checkOffline();
});


// ---- Other languages ----

const list = document.getElementById("languageList");

/** Every language mTranslate lists, paired with my language: ✅ or a Download button. */
async function listLanguages() {
  list.textContent = "";
  if (!("Translator" in self)) return;
  const mine = select.value;
  for (const code of MT.LANGUAGES) {
    if (MT.base(code) === MT.base(mine)) continue;
    const row = document.createElement("div");
    row.className = "lang";
    const name = document.createElement("span");
    name.textContent = MT.languageName(code);
    const right = document.createElement("span");
    right.className = "state";
    right.textContent = "…";
    row.append(name, right);
    list.append(row);
    showState(code, mine, right);
  }
}

async function showState(code, mine, place) {
  const [there, back] = await Promise.all([
    Translator.availability({ sourceLanguage: mine, targetLanguage: code }),
    Translator.availability({ sourceLanguage: code, targetLanguage: mine })
  ]);
  place.textContent = "";
  if (there === "unavailable" || back === "unavailable") {
    place.closest(".lang").remove(); // Chrome can't translate this pair
  } else if (there === "available" && back === "available") {
    place.textContent = "✅ Downloaded";
  } else {
    const button = document.createElement("button");
    button.textContent = "Download";
    button.addEventListener("click", () => downloadPair(code, mine, place, button));
    place.append(button);
  }
}

async function downloadPair(code, mine, place, button) {
  button.disabled = true;
  const progress = (m) => m.addEventListener("downloadprogress", (e) => {
    button.textContent = "Downloading… " + Math.round(e.loaded * 100) + "%";
  });
  try {
    await Translator.create({ sourceLanguage: mine, targetLanguage: code, monitor: progress });
    await Translator.create({ sourceLanguage: code, targetLanguage: mine, monitor: progress });
  } catch {
    button.textContent = "Try again";
    button.disabled = false;
    return;
  }
  showState(code, mine, place);
}

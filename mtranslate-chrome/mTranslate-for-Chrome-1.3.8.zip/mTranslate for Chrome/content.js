// The yellow bubble on web pages. Select text (or double-click a word) and, depending on Settings,
// the bubble opens at once, or a small mTranslate icon appears first.

(() => {
  // background.js may inject this file again into a tab that already has it.
  if (window.__mTranslateLoaded) return;
  window.__mTranslateLoaded = true;

  const MAX_LENGTH = 1000;
  // The colour speaker emoji: a little friendlier than a flat icon.
  const SPEAKER = '<span class="emoji" aria-hidden="true">🔊</span>';
  const CROSS = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>';

  let settings = { ...MT.DEFAULTS };
  MT.getSettings().then((s) => { settings = s; });
  chrome.storage.onChanged.addListener((changes) => {
    for (const [key, { newValue }] of Object.entries(changes)) settings[key] = newValue;
  });

  let host = null;
  let bubble = null;
  let shownText = "";

  // ---- when to open ----

  document.addEventListener("mouseup", (e) => {
    if (e.button !== 0 || settings.selectMode === "off" || isOurs(e) || isEditable(e.target)) return;
    // Let the browser finish updating the selection first.
    setTimeout(() => {
      const picked = readSelection();
      if (!picked || (host && picked.text === shownText)) return;
      if (settings.selectMode === "icon") showIcon(picked);
      else show(picked);
    }, 10);
  }, true);

  // Right-click → mTranslate (sent by background.js). Works in every mode.
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "show") return;
    // Answer at once, otherwise Chrome treats the message as failed.
    sendResponse({ shown: true });
    const picked = readSelection() || { text: message.text.trim().slice(0, MAX_LENGTH), rect: new DOMRect(window.innerWidth / 2, 80, 0, 0), range: null };
    show(picked);
  });

  document.addEventListener("mousedown", (e) => { if (host && !isOurs(e)) close(); }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); }, true);

  function isOurs(e) {
    return host && e.composedPath().includes(host);
  }

  function isEditable(el) {
    return el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));
  }

  function readSelection() {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return null;
    const text = selection.toString().trim();
    if (!text || text.length > MAX_LENGTH) return null;
    const range = selection.getRangeAt(0);
    return { text, rect: range.getBoundingClientRect(), range };
  }

  /** For a single word: the sentence it sits in, so the translation has some context. */
  function sentenceAround(word, range) {
    if (!range || /\s/.test(word) || word.length > 40) return null;
    let el = range.startContainer;
    if (el.nodeType === Node.TEXT_NODE) el = el.parentElement;
    if (!el) return null;
    const block = el.closest("p, li, td, th, dd, dt, blockquote, figcaption, h1, h2, h3, h4, h5, h6, div, section, article") || el;
    const text = (block.innerText || "").replace(/\s+/g, " ").trim();
    const sentences = text.split(/(?<=[.!?。！？])\s+/);
    const pattern = new RegExp("(^|[^\\p{L}])" + word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "([^\\p{L}]|$)", "u");
    const sentence = sentences.find((s) => pattern.test(s));
    if (!sentence || sentence.length > 400 || sentence.trim() === word) return null;
    return sentence.trim();
  }

  // ---- shared shell ----

  function makeHost() {
    close();
    host = document.createElement("div");
    host.setAttribute("data-mtranslate", "bubble"); // so a page translation leaves it alone
    host.style.cssText = "all:initial;position:absolute;z-index:2147483647;";
    const root = host.attachShadow({ mode: "closed" });
    document.documentElement.appendChild(host);
    return root;
  }

  function close() {
    if (host) host.remove();
    host = null;
    bubble = null;
    shownText = "";
    speechSynthesis.cancel();
  }

  // ---- small icon (Settings → "Show an icon I can click") ----

  function showIcon(picked) {
    const root = makeHost();
    shownText = picked.text;
    root.innerHTML = `
      <style>
        button { all: unset; cursor: pointer; display: block; width: 26px; height: 26px; border-radius: 6px;
          background: #fff; box-shadow: 0 1px 4px rgba(0,0,0,.3); padding: 2px; }
        img { width: 26px; height: 26px; display: block; }
      </style>
      <button title="Translate with mTranslate"><img alt="mTranslate"></button>`;
    root.querySelector("img").src = chrome.runtime.getURL("icons/icon-32.png");
    root.querySelector("button").addEventListener("mousedown", (e) => {
      e.preventDefault(); // keep the selection
      e.stopPropagation();
      show(picked);
    });
    const r = picked.rect;
    host.style.left = Math.min(r.right + 4, window.innerWidth - 40) + window.scrollX + "px";
    host.style.top = r.bottom + 4 + window.scrollY + "px";
  }

  // ---- the bubble ----

  async function show(picked) {
    const { text, rect, range } = picked;
    const root = makeHost();
    shownText = text;
    root.innerHTML = `
      <style>
        :host { all: initial; }
        .box { position: relative; box-sizing: border-box; width: 340px; background: #ffffdd; color: #222;
          border: 1px solid #bbb; border-radius: 6px; padding: 12px 14px; box-shadow: 0 3px 10px rgba(0,0,0,.2);
          font: 15px/1.45 -apple-system, BlinkMacSystemFont, "PingFang HK", sans-serif; text-align: left; }
        /* Little pointer towards the text, like a speech bubble. */
        .box::before, .box::after { content: ""; position: absolute; left: var(--tail-x, 50%); border: 9px solid transparent; transform: translateX(-50%); }
        .above::before { top: 100%; border-top-color: #bbb; }
        .above::after { top: calc(100% - 1px); border-top-color: #ffffdd; }
        .below::before { bottom: 100%; border-bottom-color: #bbb; }
        .below::after { bottom: calc(100% - 1px); border-bottom-color: #ffffdd; }
        .row { display: flex; gap: 6px; align-items: flex-start; }
        .src { flex: 1; font-size: 19px; font-weight: 700; word-break: break-word; max-height: 7.5em; overflow: auto; }
        .out { flex: 1; font-size: 17px; margin-top: 8px; word-break: break-word; max-height: 12em; overflow: auto; }
        .ctx { margin-top: 10px; padding-top: 8px; border-top: 1px solid #e6e2b0; font-size: 13px; color: #555; }
        .ctx b { font-weight: 600; color: #333; }
        .muted { color: #666; }
        button { all: unset; cursor: pointer; width: 26px; height: 26px; display: grid; place-items: center; border-radius: 4px; color: #777; flex: none; }
        button:hover { color: #333; background: rgba(0,0,0,.06); }
        svg { width: 18px; height: 18px; fill: currentColor; }
        .emoji { font: 18px/1 "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif; }
        .speaking .emoji { animation: pulse .7s ease-in-out infinite alternate; }
        @keyframes pulse { from { transform: scale(1); } to { transform: scale(1.25); } }
        .x svg { width: 14px; height: 14px; }
        .foot { display: flex; justify-content: space-between; margin-top: 10px; font-size: 13px; }
        a { color: #1a0dab; text-decoration: none; cursor: pointer; }
        a:hover { text-decoration: underline; }
        a:focus:not(:focus-visible) { outline: none; }
      </style>
      <div class="box above" role="dialog" aria-label="mTranslate">
        <div class="row"><div class="src"></div><button class="say-src" title="Read aloud">${SPEAKER}</button><button class="x" title="Close">${CROSS}</button></div>
        <div class="row"><div class="out muted">…</div><button class="say-out" title="Read aloud" hidden>${SPEAKER}</button></div>
        <div class="ctx" hidden></div>
        <div class="foot"><span class="langs muted"></span><a class="settings" target="_blank" rel="noopener">Settings</a></div>
      </div>`;
    bubble = root.querySelector(".box");
    // Settings → Text size scales the whole bubble.
    bubble.style.zoom = settings.textSize || 1;
    const $ = (s) => root.querySelector(s);
    const say = (key) => MT.label(key, settings.myLanguage);
    $(".settings").textContent = say("settings");
    $(".x").title = say("close");
    $(".say-src").title = say("speak");
    $(".say-out").title = say("speak");
    const me = host;
    $(".src").textContent = text;
    $(".x").onclick = close;
    // A plain link to the settings page (listed in web_accessible_resources), so it doesn't depend on messages.
    $(".settings").href = chrome.runtime.getURL("options.html");
    place(rect);

    const source = await MT.detect(text);
    const target = MT.targetFor(source, settings.myLanguage);
    if (host !== me) return;
    $(".langs").textContent = MT.languageName(source) + " → " + MT.languageName(target);
    $(".say-src").onclick = () => MT.speak(text, source, $(".say-src"));

    try {
      const result = await MT.translate(text, source, target, (status) => { if (host === me) $(".out").textContent = status; });
      if (host !== me) return;
      $(".out").textContent = result;
      $(".out").classList.remove("muted");
      $(".say-out").hidden = false;
      $(".say-out").onclick = () => MT.speak(result, target, $(".say-out"));
    } catch (err) {
      if (host !== me) return;
      $(".out").textContent = err.message;
      if (err.needsClick) {
        // A click inside the bubble lets Chrome download the language.
        const retry = document.createElement("a");
        retry.textContent = " Download and translate";
        retry.onclick = () => show(picked);
        $(".out").append(retry);
      }
      return;
    }
    place(rect);

    const sentence = settings.sentence ? sentenceAround(text, range) : null;
    if (!sentence) return;
    try {
      const translated = await MT.translate(sentence, source, target);
      if (host !== me) return;
      const ctx = $(".ctx");
      ctx.hidden = false;
      ctx.innerHTML = "<b></b><div></div>";
      ctx.querySelector("b").textContent = say("sentence");
      ctx.querySelector("div").textContent = translated;
      place(rect);
    } catch {
      // The word on its own is enough.
    }
  }

  function place(rect) {
    if (!host || !bubble) return;
    const zoom = Number(bubble.style.zoom) || 1;
    const box = bubble.getBoundingClientRect();
    const w = box.width || 340 * zoom, h = box.height || 120, gap = 10;
    let left = rect.left + rect.width / 2 - w / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    let top = rect.top - h - gap;
    const below = top < 8;
    if (below) top = rect.bottom + gap;
    bubble.classList.toggle("below", below);
    bubble.classList.toggle("above", !below);
    const tail = Math.max(16, Math.min(rect.left + rect.width / 2 - left, w - 16));
    bubble.style.setProperty("--tail-x", tail / zoom + "px"); // inside the zoomed box
    host.style.left = left + window.scrollX + "px";
    host.style.top = top + window.scrollY + "px";
  }
})();

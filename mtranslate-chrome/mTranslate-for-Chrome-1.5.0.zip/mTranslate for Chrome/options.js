// Settings page (right-click the toolbar icon → Options, or ⚙︎ Settings in the popup).

const select = document.getElementById("myLanguage");
const uiSelect = document.getElementById("uiLanguage");
/** The language of this page's own words. */
const ui = () => MT.uiOf({ uiLanguage: uiSelect.value });
const saved = document.getElementById("saved");
let savedTimer = null;

function save(values) {
  chrome.storage.sync.set(values, () => {
    saved.textContent = MT.t("saved", ui());
    clearTimeout(savedTimer);
    savedTimer = setTimeout(() => { saved.textContent = ""; }, 1500);
  });
}

(async () => {
  for (const code of MT.LANGUAGES) select.add(new Option(MT.languageName(code), code));
  // Interface language: "Same as Chrome", then each language in its own words.
  uiSelect.add(new Option("", ""));
  for (const code of MT.UI_LANGUAGES) uiSelect.add(new Option(MT.languageName(code), code));
  const s = await MT.getSettings();
  select.value = s.myLanguage;
  uiSelect.value = s.uiLanguage;
  showWords();
  document.querySelector(`input[name=selectMode][value=${s.selectMode}]`).checked = true;
  document.querySelector(`input[name=chineseVoice][value=${s.chineseVoice}]`).checked = true;
  const size = document.querySelector(`input[name=textSize][value="${s.textSize}"]`);
  if (size) size.checked = true;
  document.getElementById("sentence").checked = s.sentence;

  select.addEventListener("change", () => save({ myLanguage: select.value }));
  for (const radio of document.querySelectorAll("input[type=radio]")) {
    radio.addEventListener("change", () => save({ [radio.name]: radio.name === "textSize" ? Number(radio.value) : radio.value }));
  }
  document.getElementById("sentence").addEventListener("change", (e) => save({ sentence: e.target.checked }));
  select.addEventListener("change", () => { checkOffline(); listLanguages(); });
  // A new interface language: this page's own words change with it.
  uiSelect.addEventListener("change", () => {
    save({ uiLanguage: uiSelect.value });
    showWords();
    checkOffline();
    listLanguages();
  });
  checkOffline();
  listLanguages();
})();

function showWords() {
  MT.translateScreen(document, ui());
  uiSelect.options[0].textContent = MT.t("same_as_chrome", ui());
}

// ---- Use without internet ----

const offlineStatus = document.getElementById("offlineStatus");
const offlineButton = document.getElementById("offlineButton");

/** My language and the one it's translated into (English, or Chinese if my language is English). */
function offlinePair() {
  const mine = select.value;
  return [mine, MT.targetFor(mine, mine)];
}

async function checkOffline() {
  const [a, b] = offlinePair();
  document.getElementById("offlinePair").textContent = MT.languageName(a) + " ⇄ " + MT.languageName(b);
  if (!("Translator" in self)) {
    offlineStatus.textContent = MT.t("no_builtin_short", ui());
    offlineButton.hidden = true;
    return;
  }
  const [there, back] = await Promise.all([
    MT.availability(a, b).catch(() => "unavailable"),
    MT.availability(b, a).catch(() => "unavailable")
  ]);
  if (there === "unavailable" || back === "unavailable") {
    offlineStatus.textContent = MT.t("not_available", ui());
    offlineButton.hidden = true;
  } else if (there === "available" && back === "available") {
    offlineStatus.textContent = MT.t("ready", ui());
    offlineButton.hidden = true;
  } else {
    offlineStatus.textContent = MT.t("not_downloaded", ui());
    offlineButton.hidden = false;
  }
}

// The button press lets Chrome download the languages (it needs a click).
offlineButton.addEventListener("click", async () => {
  const [a, b] = offlinePair();
  offlineButton.disabled = true;
  const progress = (m) => m.addEventListener("downloadprogress", (e) => {
    offlineStatus.textContent = MT.t("downloading", ui()) + " " + Math.round(e.loaded * 100) + "%";
  });
  try {
    offlineStatus.textContent = MT.t("downloading", ui());
    await Translator.create({ sourceLanguage: a, targetLanguage: b, monitor: progress });
    await Translator.create({ sourceLanguage: b, targetLanguage: a, monitor: progress });
    if ("LanguageDetector" in self) await LanguageDetector.create({ monitor: progress });
  } catch {
    offlineStatus.textContent = MT.t("download_failed", ui());
    offlineButton.disabled = false;
    return;
  }
  offlineButton.disabled = false;
  checkOffline();
});


// ---- Other languages ----

const list = document.getElementById("languageList");

/** Every language mTranslate lists, paired with my language: ✅ or a Download button. */
async function listLanguages() {
  list.textContent = "";
  if (!("Translator" in self)) return;
  const mine = select.value;
  for (const code of MT.LANGUAGES) {
    if (MT.base(code) === MT.base(mine)) continue;
    const row = document.createElement("div");
    row.className = "lang";
    const name = document.createElement("span");
    name.textContent = MT.languageName(code);
    const right = document.createElement("span");
    right.className = "state";
    right.textContent = "…";
    row.append(name, right);
    list.append(row);
    showState(code, mine, right);
  }
}

async function showState(code, mine, place) {
  const [there, back] = await Promise.all([
    MT.availability(mine, code).catch(() => "unavailable"),
    MT.availability(code, mine).catch(() => "unavailable")
  ]);
  place.textContent = "";
  if (there === "unavailable" || back === "unavailable") {
    place.closest(".lang").remove(); // Chrome can't translate this pair
  } else if (there === "available" && back === "available") {
    place.textContent = MT.t("downloaded", ui());
  } else {
    const button = document.createElement("button");
    button.textContent = MT.t("download", ui());
    button.addEventListener("click", () => downloadPair(code, mine, place, button));
    place.append(button);
  }
}

async function downloadPair(code, mine, place, button) {
  button.disabled = true;
  const progress = (m) => m.addEventListener("downloadprogress", (e) => {
    button.textContent = MT.t("downloading", ui()) + " " + Math.round(e.loaded * 100) + "%";
  });
  try {
    await Translator.create({ sourceLanguage: mine, targetLanguage: code, monitor: progress });
    await Translator.create({ sourceLanguage: code, targetLanguage: mine, monitor: progress });
  } catch {
    button.textContent = MT.t("try_again", ui());
    button.disabled = false;
    return;
  }
  showState(code, mine, place);
}

// Right-click menu: translate the selected text, or the whole page (or show the original again).
// Kept on its own (no shared.js), so nothing page-only can stop it from starting.

const PAGE_FILES = ["i18n.js", "shared.js", "content.js", "page.js"];

// The page item in the user's language; others use English.
const TRANSLATE_PAGE = {
  en: "Translate this page", "zh-Hant": "翻譯此網頁", zh: "翻译此网页", ja: "このページを翻訳",
  ko: "이 페이지 번역", fr: "Traduire cette page", de: "Diese Seite übersetzen", es: "Traducir esta página",
  it: "Traduci questa pagina", pt: "Traduzir esta página", vi: "Dịch trang này", th: "แปลหน้านี้", id: "Terjemahkan halaman ini"
};
const SHOW_ORIGINAL = {
  en: "Show original", "zh-Hant": "顯示原文", zh: "显示原文", ja: "原文を表示", ko: "원문 보기",
  fr: "Afficher l'original", de: "Original anzeigen", es: "Mostrar original", it: "Mostra originale",
  pt: "Mostrar original", vi: "Hiển thị bản gốc", th: "แสดงต้นฉบับ", id: "Tampilkan asli"
};
const LANGUAGES = ["zh-Hant", "zh", "en", "ja", "ko", "fr", "de", "es", "it", "pt", "nl", "sv", "da", "fi", "no",
  "pl", "cs", "ru", "uk", "tr", "ar", "he", "hi", "bn", "th", "vi", "id", "ms"];

/** Same rule as shared.js: a new user's language is Chrome's own. */
function chromeLanguage() {
  const ui = chrome.i18n.getUILanguage().replace("_", "-");
  if (/^zh-(TW|HK|MO|Hant)/i.test(ui)) return "zh-Hant";
  const code = ui.split("-")[0].toLowerCase();
  if (code === "zh") return "zh";
  if (code === "nb" || code === "nn") return "no";
  return LANGUAGES.includes(code) ? code : "en";
}

const pick = (words, lang) => words[lang] || words[lang.split("-")[0]] || words.en;

/**
 * Tabs whose page is translated right now, so the icon is green and the menu offers "Show original".
 * The page itself is the one that knows (see refreshTab); this is just the latest answer.
 */
const translatedTabs = new Set();
let currentTab = null;

let menuJob = Promise.resolve();
function makeMenus() {
  // One at a time: two runs side by side would create the same items twice.
  menuJob = menuJob.then(buildMenus, buildMenus);
  return menuJob;
}

async function buildMenus() {
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({ id: "mtranslate", title: "mTranslate “%s”", contexts: ["selection"] }, logError);
  chrome.contextMenus.create({ id: "mtranslate-page", title: await pageTitle(), contexts: ["page"] }, logError);
}

/** In the Interface language (Settings), or Chrome's. */
async function pageTitle() {
  const { uiLanguage } = await chrome.storage.sync.get({ uiLanguage: "" });
  const words = translatedTabs.has(currentTab) ? SHOW_ORIGINAL : TRANSLATE_PAGE;
  return "mTranslate: " + pick(words, uiLanguage || chromeLanguage());
}

async function updatePageItem() {
  chrome.contextMenus.update("mtranslate-page", { title: await pageTitle() }, logError);
}

function logError() {
  if (chrome.runtime.lastError) console.warn("mTranslate menu:", chrome.runtime.lastError.message);
}

// Every time the background starts, not only at install: a missed install event would leave no menu.
makeMenus();
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  // People who had mTranslate before it followed Chrome's language keep Traditional Chinese.
  if (reason === "update") {
    const saved = await chrome.storage.sync.get("myLanguage");
    if (!saved.myLanguage) await chrome.storage.sync.set({ myLanguage: "zh-Hant" });
  }
  makeMenus();
});
chrome.storage.onChanged.addListener((changes) => { if (changes.uiLanguage) makeMenus(); });

// Keep the icon and the page item right. The background can be stopped and started by Chrome,
// and mTranslate can be reloaded, so rather than remember, ask the page.
chrome.tabs.onActivated.addListener(({ tabId }) => { currentTab = tabId; refreshTab(tabId); });
chrome.tabs.onUpdated.addListener((tabId, change) => { if (change.status === "complete") refreshTab(tabId); });
chrome.tabs.onRemoved.addListener((tabId) => translatedTabs.delete(tabId));

/** Asks the tab's page whether it's translated (no answer: it isn't). */
async function refreshTab(tabId) {
  let translated = false;
  try {
    const state = await chrome.tabs.sendMessage(tabId, { type: "pageState?" }, { frameId: 0 });
    translated = Boolean(state && (state.active || state.stale));
  } catch {
    // no mTranslate on that page (yet), or a chrome:// page
  }
  setTranslated(tabId, translated);
}

function setTranslated(tabId, translated) {
  if (translated) translatedTabs.add(tabId);
  else translatedTabs.delete(tabId);
  showIcon(tabId, translated);
  if (tabId === currentTab) updatePageItem();
}

/** On a tab whose page is translated, the toolbar icon sits on a bright red square; normal again afterwards. */
function showIcon(tabId, translated) {
  const set = translated ? "on" : "toolbar";
  chrome.action.setIcon({ tabId, path: { 16: `icons/${set}-16.png`, 32: `icons/${set}-32.png`, 48: `icons/${set}-48.png` } }).catch(() => {});
}

// After a start or reload of mTranslate: find the tab in front and ask it.
chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
  if (tab) { currentTab = tab.id; refreshTab(tab.id); }
}).catch(() => {});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const frameId = info.frameId ?? 0;
  if (info.menuItemId === "mtranslate" && info.selectionText) {
    const sent = await send(tab.id, { type: "show", text: info.selectionText }, frameId);
    // The extension can't run on this page (chrome:// pages, the PDF viewer): use the full page instead.
    if (!sent) openPage(info.selectionText, tab);
  }
  if (info.menuItemId === "mtranslate-page") {
    await send(tab.id, { type: "page" }, 0);
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  // page.js says whether its page is translated.
  if (message.type === "pageState" && sender.tab) {
    if (sender.tab.active) currentTab = sender.tab.id;
    setTranslated(sender.tab.id, Boolean(message.active || message.stale));
  }
});

/** Sends a message to the page; adds our scripts first to tabs opened before the extension was installed or updated. */
async function send(tabId, message, frameId) {
  try {
    await chrome.tabs.sendMessage(tabId, message, { frameId });
    return true;
  } catch {
    // no scripts in this tab yet
  }
  try {
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: PAGE_FILES });
    await chrome.tabs.sendMessage(tabId, message, { frameId });
    return true;
  } catch {
    return false;
  }
}

function openPage(text, tab) {
  chrome.tabs.create({
    url: "translate.html?full=1&text=" + encodeURIComponent(text.slice(0, 5000)),
    index: tab ? tab.index + 1 : undefined
  });
}

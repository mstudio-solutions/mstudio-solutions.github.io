// Shared by the page bubble (content script), the toolbar popup, the full page and the settings page.
// Translation uses Chrome's built-in Translator: on this computer, free, nothing sent anywhere.

// `var` + check, because background.js may inject this file again into a page that has it.
var MT = globalThis.MT || (() => {
  // Chrome doesn't list its translator languages, so these are the common ones it supports.
  const LANGUAGES = ["zh-Hant", "zh", "en", "ja", "ko", "fr", "de", "es", "it", "pt", "nl", "sv", "da", "fi", "no",
    "pl", "cs", "ru", "uk", "tr", "ar", "he", "hi", "bn", "th", "vi", "id", "ms"];

  /** A new user's language is Chrome's own (Hong Kong and Taiwan Chinese → Traditional). */
  function chromeLanguage() {
    const ui = (chrome.i18n && chrome.i18n.getUILanguage ? chrome.i18n.getUILanguage() : "en").replace("_", "-");
    if (/^zh-(TW|HK|MO|Hant)/i.test(ui)) return "zh-Hant";
    const code = ui.split("-")[0].toLowerCase();
    if (code === "zh") return "zh";
    if (code === "nb" || code === "nn") return "no";
    return LANGUAGES.includes(code) ? code : "en";
  }

  // The languages mTranslate's own words come in (i18n.js).
  const UI_LANGUAGES = ["en", "zh-Hant", "zh", "ja", "ko", "fr", "de", "es", "it", "pt", "vi", "th", "id"];

  const DEFAULTS = {
    uiLanguage: "", // mTranslate's own words; "" = same as Chrome
    myLanguage: chromeLanguage(),
    selectMode: "popup", // "popup" | "icon" | "off"
    chineseVoice: "yue", // "yue" (Cantonese) | "zh" (Mandarin)
    sentence: true, // single word: also translate the sentence around it
    textSize: 1 // 0.9 small, 1 medium, 1.2 large, 1.4 extra large
  };


  // The bubble's own words, in the reader's language (My language). Others fall back to English.
  const LABELS = {
    en: { sentence: "The whole sentence", settings: "Settings", speak: "Read aloud", close: "Close" },
    "zh-Hant": { sentence: "全句翻譯", settings: "設定", speak: "讀出", close: "關閉" },
    zh: { sentence: "全句翻译", settings: "设置", speak: "朗读", close: "关闭" },
    ja: { sentence: "文全体の翻訳", settings: "設定", speak: "読み上げ", close: "閉じる" },
    ko: { sentence: "전체 문장 번역", settings: "설정", speak: "읽어 주기", close: "닫기" },
    fr: { sentence: "La phrase entière", settings: "Réglages", speak: "Lire à voix haute", close: "Fermer" },
    de: { sentence: "Der ganze Satz", settings: "Einstellungen", speak: "Vorlesen", close: "Schließen" },
    es: { sentence: "La frase completa", settings: "Ajustes", speak: "Leer en voz alta", close: "Cerrar" },
    it: { sentence: "La frase intera", settings: "Impostazioni", speak: "Leggi ad alta voce", close: "Chiudi" },
    pt: { sentence: "A frase completa", settings: "Definições", speak: "Ler em voz alta", close: "Fechar" },
    vi: { sentence: "Cả câu", settings: "Cài đặt", speak: "Đọc to", close: "Đóng" },
    th: { sentence: "ทั้งประโยค", settings: "การตั้งค่า", speak: "อ่านออกเสียง", close: "ปิด" },
    id: { sentence: "Seluruh kalimat", settings: "Pengaturan", speak: "Bacakan", close: "Tutup" }
  };

  // Words for translating a whole page. Languages not listed here use English.
  const PAGE_LABELS = {
    en: { translatedTo: "Translated to", translating: "Translating…", showOriginal: "Show original", alreadyIn: "This page is already in", download: "Download and translate", translatePage: "Translate this page" },
    "zh-Hant": { translatedTo: "已翻譯成", translating: "翻譯中…", showOriginal: "顯示原文", alreadyIn: "此網頁已經是", download: "下載並翻譯", translatePage: "翻譯此網頁" },
    zh: { translatedTo: "已翻译成", translating: "翻译中…", showOriginal: "显示原文", alreadyIn: "此网页已经是", download: "下载并翻译", translatePage: "翻译此网页" },
    ja: { translatedTo: "翻訳先:", translating: "翻訳中…", showOriginal: "原文を表示", alreadyIn: "このページはすでに", download: "ダウンロードして翻訳", translatePage: "このページを翻訳" },
    ko: { translatedTo: "번역됨:", translating: "번역 중…", showOriginal: "원문 보기", alreadyIn: "이 페이지는 이미", download: "다운로드 후 번역", translatePage: "이 페이지 번역" }
  };

  function label(key, myLanguage) {
    const code = myLanguage.split("-")[0];
    const set = { ...LABELS.en, ...PAGE_LABELS.en, ...(LABELS[code] || {}), ...(PAGE_LABELS[code] || {}),
      ...(LABELS[myLanguage] || {}), ...(PAGE_LABELS[myLanguage] || {}) };
    return set[key];
  }

  /** The language of mTranslate's own words: the Interface language setting, or Chrome's. */
  function uiOf(settings) {
    if (settings.uiLanguage) return settings.uiLanguage;
    const chrome = chromeLanguage();
    return UI_LANGUAGES.includes(chrome) ? chrome : "en";
  }

  // Kept up to date by getSettings().
  let uiLanguage = uiOf(DEFAULTS);

  function getSettings() {
    // Without access to mTranslate (see content.js), fall back to the defaults instead of crashing.
    if (!globalThis.chrome || !chrome.storage) return Promise.resolve({ ...DEFAULTS });
    return new Promise((resolve) => chrome.storage.sync.get(DEFAULTS, (s) => {
      uiLanguage = uiOf(s);
      resolve(s);
    }));
  }

  /** A word on screen (from i18n.js) in My language, or in English. */
  function t(id, lang = uiLanguage) {
    const words = globalThis.MT_WORDS || {};
    const set = words[lang] || words[lang.split("-")[0]] || {};
    return set[id] || (words.en || {})[id] || id;
  }

  /** Puts the words into a page: data-i18n (text), data-i18n-title, data-i18n-placeholder. */
  function translateScreen(root, lang = uiLanguage) {
    document.documentElement.lang = lang;
    for (const el of root.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n, lang);
    for (const el of root.querySelectorAll("[data-i18n-title]")) {
      el.title = t(el.dataset.i18nTitle, lang);
      el.setAttribute("aria-label", el.title);
    }
    for (const el of root.querySelectorAll("[data-i18n-placeholder]")) el.placeholder = t(el.dataset.i18nPlaceholder, lang);
  }

  /** Each language in its own words: 中文（繁體）, English, 日本語 … */
  function languageName(code) {
    if (code === "zh-Hant") return "中文（繁體）";
    if (code === "zh") return "中文（简体）";
    try {
      const name = new Intl.DisplayNames([code], { type: "language" }).of(code);
      return name.charAt(0).toLocaleUpperCase(code) + name.slice(1);
    } catch {
      return code;
    }
  }

  const base = (code) => code.split("-")[0];

  // Japanese also uses Chinese characters, but always with kana; Korean has hangul.
  const KANA = /[\u3040-\u30ff\u31f0-\u31ff\uff66-\uff9f]/;
  const HANGUL = /[\u1100-\u11ff\u3130-\u318f\uac00-\ud7af]/;

  function looksChinese(text) {
    if (KANA.test(text) || HANGUL.test(text)) return false;
    const han = (text.match(/[㐀-鿿]/g) || []).length;
    return han > 0 && han >= text.replace(/\s/g, "").length / 3;
  }

  let detector = null;
  /** pageLanguage (optional, from <html lang>) settles words written only in kanji, like 購入. */
  async function detect(text, pageLanguage = "") {
    if (KANA.test(text)) return "ja";
    if (HANGUL.test(text)) return "ko";
    if (looksChinese(text)) return /^ja\b/i.test(pageLanguage) ? "ja" : "zh-Hant";
    if ("LanguageDetector" in self) {
      try {
        detector = detector || (await LanguageDetector.create());
        // Take the most likely language mTranslate can translate. Close languages can share
        // words (Portuguese can come out as Galician first), so the next guess may be the one.
        const guesses = await detector.detect(text);
        const usable = guesses.find((g) => g.confidence > 0.2 && LANGUAGES.includes(base(g.detectedLanguage) === "zh" ? "zh" : base(g.detectedLanguage)));
        if (usable) return base(usable.detectedLanguage) === "zh" ? "zh-Hant" : base(usable.detectedLanguage);
      } catch {
        // fall through to the simple guess
      }
    }
    return "en";
  }

  /** Text already in my language goes into English (or into Chinese if my language is English). */
  function targetFor(source, myLanguage) {
    if (base(source) !== base(myLanguage)) return myLanguage;
    return base(myLanguage) === "en" ? "zh-Hant" : "en";
  }

  const translators = new Map();

  function withTimeout(promise, ms, message) {
    return Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms))]);
  }

  /**
   * onStatus(text) shows progress, for example while Chrome downloads a language the first time.
   * A download needs a click or key press; without one the error has needsClick = true.
   */
  async function translate(text, source, target, onStatus = () => {}) {
    if (base(source) === base(target) && source !== "zh" && target !== "zh") return text;
    if (!("Translator" in self)) throw new Error(t("no_builtin"));
    const key = source + ">" + target;
    try {
      return await (await translatorFor(key, source, target, onStatus)).translate(text);
    } catch (err) {
      if (err.mtranslate) throw err; // our own message (needs a click, not supported…)
      // Chrome can close a translator after a while or after a lot of work; a closed one
      // fails every time. Make a fresh one and try once more.
      translators.delete(key);
      try {
        return await (await translatorFor(key, source, target, onStatus)).translate(text);
      } catch (again) {
        translators.delete(key);
        if (again.mtranslate) throw again;
        throw new Error(t("try_moment"));
      }
    }
  }

  /**
   * Can Chrome translate from → to? For some languages Chrome throws instead of answering
   * "unavailable" ("The requested language options are not supported"); that counts as unavailable.
   */
  async function availability(from, to) {
    try {
      return await Translator.availability({ sourceLanguage: from, targetLanguage: to });
    } catch (err) {
      if (err && err.name === "NotSupportedError") return "unavailable";
      throw err;
    }
  }

  /** The translator for this pair, made once and kept; errors come back with our own message. */
  async function translatorFor(key, source, target, onStatus) {
    const fail = (message, needsClick = false) => Object.assign(new Error(message), { mtranslate: true, needsClick });
    if (!translators.has(key)) {
      const ask = (from) => withTimeout(availability(from, target), 8000, t("no_answer"));
      let from = source;
      let status;
      try {
        status = await ask(from);
        if (status === "unavailable" && from === "zh-Hant") {
          // Some Chrome versions only accept plain "zh" as a source.
          from = "zh";
          status = await ask(from);
        }
      } catch (err) {
        throw fail(err.message);
      }
      if (status === "unavailable") throw fail(t("pair_unsupported_chrome"));
      if (status !== "available") onStatus(t("downloading_once"));
      translators.set(key, Translator.create({ sourceLanguage: from, targetLanguage: target }));
    }
    try {
      return await translators.get(key);
    } catch (err) {
      translators.delete(key);
      const needsClick = Boolean(err && err.name === "NotAllowedError");
      throw fail(needsClick ? t("needs_click") : t("not_ready"), needsClick);
    }
  }


  // ---- voice ----

  let voices = [];
  const loadVoices = () => { voices = speechSynthesis.getVoices().filter((v) => v.localService); };
  // The background worker loads this file too, and has no voices.
  if (typeof speechSynthesis !== "undefined") {
    loadVoices();
    speechSynthesis.addEventListener("voiceschanged", loadVoices);
  }

  // macOS also lists novelty voices (Albert, Bells, …); the usual ones come first.
  const PREFERRED = ["Sinji", "Meijia", "Tingting", "Samantha", "Daniel", "Karen", "Moira", "Kyoko", "Yuna", "Thomas", "Anna", "Mónica", "Alice"];

  function voiceFor(lang, chineseVoice) {
    let wants;
    if (base(lang) === "zh") wants = chineseVoice === "zh" ? ["zh-TW", "zh-CN"] : ["yue-HK", "zh-HK", "zh-TW"];
    else if (base(lang) === "en") wants = ["en-US", "en-GB", "en-AU", "en"];
    else wants = [lang];
    for (const want of wants) {
      const matching = voices.filter((v) => v.lang.replace("_", "-").startsWith(want));
      const voice = matching.find((v) => PREFERRED.some((p) => v.name.startsWith(p))) || matching.find((v) => v.default) || matching[0];
      if (voice) return voice;
    }
    return null;
  }

  /** Press once to hear it, press again to stop. Only the Mac's own voices: Google's online voices would send the text to Google. */
  // button (optional) pulses while it reads.
  let speakingButton = null;
  async function speak(text, lang, button) {
    if (speechSynthesis.speaking) {
      speechSynthesis.cancel();
      if (speakingButton) speakingButton.classList.remove("speaking");
      return;
    }
    const { chineseVoice } = await getSettings();
    // On a newly opened page Chrome may not have its voice list yet; without it, Chrome would
    // read in its default (English) voice. Wait for the list, at most a second.
    if (!voices.length) loadVoices();
    if (!voices.length) {
      await new Promise((ready) => {
        const done = () => { loadVoices(); ready(); };
        speechSynthesis.addEventListener("voiceschanged", done, { once: true });
        setTimeout(done, 1000);
      });
    }
    const u = new SpeechSynthesisUtterance(text);
    const voice = voiceFor(lang, chineseVoice);
    u.voice = voice;
    u.lang = voice ? voice.lang : lang;
    if (button) {
      speakingButton = button;
      button.classList.add("speaking");
      u.onend = u.onerror = () => button.classList.remove("speaking");
    }
    speechSynthesis.speak(u);
  }

  return { DEFAULTS, LANGUAGES, UI_LANGUAGES, uiOf, label, t, translateScreen, getSettings, availability, languageName, detect, targetFor, translate, speak, base };
})();
